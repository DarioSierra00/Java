package com.edu.mock24.model;

public interface Valorable{
	
	//public boolean valorar(String valoracion) {
		
	//}
}
