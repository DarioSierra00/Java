package com.edu.mock24.model.interfaces;

import com.edu.mock24.model.enumerados.Valoraciones;

public interface Valorable {
	
	public boolean valorar(Valoraciones valoracion);
}
