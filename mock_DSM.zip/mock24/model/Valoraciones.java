package com.edu.mock24.model;

public enum Valoraciones {
	MUYBUENA(2),
	NORMAL(1),
	MUYMALA(-2);
	
	
	
	Valoraciones(int valoraciones) {
		
	}
}
